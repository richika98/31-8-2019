import { Component, OnInit } from '@angular/core';
import { MyServiceService, Transaction } from '../my-service.service';

@Component({
  selector: 'app-mini-statement',
  templateUrl: './mini-statement.component.html',
  styleUrls: ['./mini-statement.component.css']
})
export class MiniStatementComponent implements OnInit {

    service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
  }
  model: any = {};
transaction:Transaction[]=[];
show:boolean=true;
contains:boolean=true;
acc:string
  miniStatement(data:any){
     this.acc=data.account;this.show=false;
     if(this.acc=="")
    window.alert("Data not provided properly");
    else{
    this.transaction=this.service.miniStatement(this.acc); 
    if(this.transaction.length==0)
     window.alert("No transactions available");
  }
}

  ngOnInit() {
  }

}
