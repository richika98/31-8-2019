import { Component, OnInit } from '@angular/core';
import { MyServiceService, Account } from '../my-service.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  service:MyServiceService;
  account:Account;
  message:string;
  constructor(service:MyServiceService) { 
    this.service=service;
  }
  model: any = {};
  ifExists:boolean=true;

deposit(data:any){
    let acc:string=data.account;
    let amount:number=data.amount;
    if( amount==0)
    window.alert("Amount should not be 0");
    else{
    this.account= this.service.deposit(acc,amount);
    this.ifExists=false;
    if(this.account==null){
      this.message="This account doesn't exists. Please try with valid account number";

    }
    else{
      window.alert("Deposited");
    this.message="Your current balance is : "+this.account.balance;
    }
  }
}

  ngOnInit() {
  }

}
