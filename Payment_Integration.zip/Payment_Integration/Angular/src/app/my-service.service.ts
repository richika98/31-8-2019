import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { concat } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
http:HttpClient;
account:Account[]=[];
transaction:Transaction[]=[];
accountFetched:boolean=false;
transId:number=0;

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchAccount();
  }

fetchAccount(){
  this.http.get('./assets/Account.json').subscribe(
  data=>{
    if(!this.accountFetched){
      this.convert(data);
      this.accountFetched=true;
    }
  }
);
}

convert(data:any){
  for(let o of data){
    let p = new Account(o.name,o.contact,o.address,o.balance,o.accountNumber);
    this.account.push(p);
  }
    }

    getAccount():Account[]{
      return this.account;
    }

    create(acc:Account){
      
      let jsonObj={
        "accountNumber":"",
        "custName":acc.name,
        "mobileNumber":acc.contact,
        "custAddress":acc.address,
        "balance":acc.balance
      }

      return this.http.post('http://localhost:2922/create/'
      ,jsonObj)

    /*  let aNum:string;
      aNum=acc.name.substr(0,4).toUpperCase();
      aNum+=acc.contact.toString();
      acc.accountNumber=aNum;
      this.account.push(acc);
      console.log(this.account.length);
      window.alert("Your account number:"+acc.accountNumber);
      */
    }

    deposit(acc:string,amount:any){
      return this.http.put('http://localhost:2922/deposit/'
      + acc+'/'+amount,null)
      
      /*let a:Account;
      let flag : boolean=false;
     console.log(this.account.length);
      for(let i=0;i<this.account.length;i++){
        a=this.account[i];
        if(a.accountNumber==acc){
          
          a.balance=a.balance + parseInt(amount);
          //Transaction 
          let trans=new Transaction(++this.transId,acc,"Deposit",amount,"-","-");
          this.transaction.push(trans);
          flag=true;
          break;
        }
        }
        if(flag==true)
        return a;
        else{
        return null;
        }
    */

}

showBalance(acc:string){
  

  return this.http.get('http://localhost:2922/showBalance/'
      + acc)
  /*
  let a:Account;
  let flag : boolean=false;
  for(let i=0;i<this.account.length;i++){
    a=this.account[i];
    if(a.accountNumber==acc){
      flag=true;
      break;
    }
   
  }
  if(flag==true)
  return a;
  else{
  return null;  */
  
}

  withdraw(acc:string,amount:number){

    return this.http.put('http://localhost:2922/withdraw/'
    + acc+'/'+amount,null)


    /*let a:Account;
    let message:string;
    for(let i=0;i<this.account.length;i++){
      a=this.account[i];
      if(a.accountNumber==acc){
        if( a.balance>amount){
        a.balance=a.balance - amount;
        message="Amount withdrawn successfully. Your available balance is :"+a.balance;
         //Transaction 
         let trans=new Transaction(++this.transId,acc,"Withdraw",amount,"-","-");
         this.transaction.push(trans);
         window.alert("Withdraw Successful!!");
         break;
       }
       else
         { message="Low balance!!";}
        }
      else{
      message="This account doesn't exists!!";
      }
    }
    return message; */
  }

  transfer(sender:string,receiver:string,amount:number){

    return this.http.put('http://localhost:2922/transfer/'
    + sender+'/'+receiver+'/'+amount,null)

    /*
    let acc:Account;
    let sAccount:Account;
    let  rAccount:Account;
    let message:string;
    for(let i=0;i<this.account.length;i++){
      acc=this.account[i];
      if(acc.accountNumber==sender)
       sAccount=acc;
      if(acc.accountNumber==receiver){
        rAccount =acc;
    }
  }
    if(sAccount==rAccount){
      message="Receiver's and Sender's Account can't be same";
    }
    else if(sAccount==null)
      message="Sender doesn't exists !!";
    else if(rAccount== null)
    message="Receiver doesn't exists !!";
    else
    {
      if(sAccount.balance>=amount){
      sAccount.balance=sAccount.balance-amount;
      rAccount.balance=rAccount.balance+amount;
       //Transaction 
       let trans=new Transaction(++this.transId,sender,"Transfer",amount,receiver,"-");
       this.transaction.push(trans);
       let trans2=new Transaction(++this.transId,receiver,"Received",amount,"-",sender);
       this.transaction.push(trans2);
      message="Amount transferred successfully\nYour available balance is :"+sAccount.balance;
      }
      else
      message="Insufficient Balance!!";
    }
    return message; */
    }


    miniStatement(acc:string){

      return this.http.put('http://localhost:2922/print/'
      + acc,null)

      /*let trans:Transaction[]=[];
      let a:Transaction;
      console.log(this.transaction.length);
      for(let i=0;i<this.transaction.length;i++){
        a=this.transaction[i];
        if(a.accountNumber==acc)
       trans.push(a);
    }
    return trans;
  } */

  }
}

export class Account{
  name:string;
  contact:number;
  address:string;
  balance:number;
  accountNumber:string;
  constructor(name:string, contact:number,address:string,balance:number,accountNumber:string){
    this.name=name;
    this.contact=contact;
    this.address=address;
    this.balance=balance;
    this.accountNumber=accountNumber;
  }
}

export class Transaction{
  transactionId:number;
  accountNumber:string;
  type:string;
  amount:number;
  to:string;
  from:string;

  constructor(transactionId:number,accountNumber:string, type:string,  amount:number,to:string, from:string){
    this.transactionId=transactionId;
    this.accountNumber=accountNumber;
    this.amount=amount;
    this.from=from;
    this.to=to;
    this.type=type;
  }
}