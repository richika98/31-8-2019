import { Component, OnInit } from '@angular/core';
import { MyServiceService, Account } from '../my-service.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  model: any = {};
  message:string;
ifExists:boolean=true;

  withdraw(data:any){
    let acc:string=data.account;
    let amount:number=data.amount;
    if(amount==0)
    window.alert("Amount should not be 0");
    else{
    this.ifExists=false;
    this.service.withdraw(acc,amount);
    window.alert(this.message);
  }
  }
}
