import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateComponent } from './create/create.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { TransferComponent } from './transfer/transfer.component';
import { MiniStatementComponent } from './mini-statement/mini-statement.component';


const routes: Routes = [
  {
    path:'create',
    component:CreateComponent
  },
  {
    path:'show',
    component:ShowBalanceComponent
  },
  {
    path:'deposit',
    component:DepositComponent
  },
  {
    path:'withdraw',
    component:WithdrawComponent
  },
  {
    path:'transfer',
    component:TransferComponent
  },
  {
    path:'mini-statement',
    component:MiniStatementComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
