package com.cg.service;

import java.util.List;

import javax.validation.Valid;

import com.cg.entities.Account;
import com.cg.entities.Transaction;

import UserExceptions.AccountNotFoundException;


public interface BankService {
	Account createAccount(Account account);
	long showBalance(String accountNumber) throws AccountNotFoundException;
	long deposit(String accountNumber,Long balance) throws AccountNotFoundException;
	long withdraw(String accountNumber,Long balance) throws AccountNotFoundException;
	List<Account> transfer(@Valid String sAccountNumber, String rAccountNumber, Long balance) throws AccountNotFoundException;
	List<Transaction> printTranscation(@Valid String accountNumber) throws  AccountNotFoundException;
}
