package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entities.Account;
import com.cg.entities.Transaction;
import com.cg.repository.BankRepository;
import com.cg.repository.TransactionRepository;

import UserExceptions.AccountNotFoundException;

@Service("service")
public class BankServiceImpl implements BankService {

	@Autowired
	BankRepository dao;
	@Autowired
	TransactionRepository tdao;

	public String createAccount(Account account) {
		char[] ch = account.getCustName().toCharArray();
		String accountNum = "";
		for (int i = 0; i < 4; i++) {
			ch[i] = Character.toUpperCase(ch[i]);
			accountNum = accountNum + ch[i]; // generating account number
		}
		accountNum = accountNum + account.getMobileNumber();
		account.setAccountNumber(accountNum);
		dao.save(account);
		return account.getAccountNumber();
	}

	public long showBalance(String accountNumber) throws AccountNotFoundException {
		if (dao.existsById(accountNumber)) {
			Optional<Account> a = dao.findById(accountNumber);

			Account acc = a.get();
			return acc.getBalance();
		}

		else
			throw new AccountNotFoundException("This Account Doesn't exists");
	}

	public long deposit(String accountNumber, Long balance) throws AccountNotFoundException {
		if (dao.existsById(accountNumber)) {
			Optional<Account> a = dao.findById(accountNumber);

			Account acc = a.get();
			// System.out.println(acc.getBalance());
			long newBalance = acc.getBalance() + balance;
			acc.setBalance(newBalance);
			dao.save(acc);
			Transaction trans = new Transaction();
			trans.setTransAmount(balance);
			trans.setTransFrom("-");
			trans.setTransTo("-");
			trans.setType("Deposit");
			trans.setAccountNumber(accountNumber);
			tdao.save(trans);

			return newBalance;
		} else

			throw new AccountNotFoundException("This Account Doesn't exists");
	}

	public long withdraw(String accountNumber, Long balance) throws AccountNotFoundException {
		if (dao.existsById(accountNumber)) {
			Optional<Account> a = dao.findById(accountNumber);

			Account acc = a.get();
			// System.out.println(acc.getBalance());
			if (acc.getBalance() >= balance) {
				long newBalance = acc.getBalance() - balance;
				acc.setBalance(newBalance);
				System.out.println(newBalance);
				dao.save(acc);
				Transaction trans = new Transaction();
				trans.setTransAmount(balance);
				trans.setTransFrom("-");
				trans.setTransTo("-");
				trans.setAccountNumber(accountNumber);
				trans.setType("Withdraw");
				tdao.save(trans);

				return newBalance;
			}
			throw new AccountNotFoundException("Low Balance!!");
		} else

			throw new AccountNotFoundException("This Account Doesn't exists");
	}

	@Override
	public List<Account> transfer(@Valid String sAccountNumber, String rAccountNumber, Long balance)
			throws AccountNotFoundException {

		if (!dao.existsById(sAccountNumber))
			throw new AccountNotFoundException("Sender's account doesn't exists");
		if (!dao.existsById(rAccountNumber))
			throw new AccountNotFoundException("Receiver's account doesn't exists");
		if (dao.existsById(sAccountNumber) && dao.existsById(sAccountNumber)) {
			Optional<Account> s = dao.findById(sAccountNumber);
			Optional<Account> r = dao.findById(rAccountNumber);
			Account sAcc = s.get();
			Account rAcc = r.get();
			if (sAcc.getBalance() >= balance) {
				long sBalance = sAcc.getBalance() - balance;
				long rBalance = rAcc.getBalance() + balance;
				sAcc.setBalance(sBalance);
				rAcc.setBalance(rBalance);
				dao.save(sAcc);
				dao.save(rAcc);

				Transaction trans = new Transaction();
				trans.setTransAmount(balance);
				trans.setTransFrom("-");
				trans.setTransTo(rAccountNumber);
				trans.setAccountNumber(sAccountNumber);
				trans.setType("Transfer");
				tdao.save(trans);

				Transaction trans2 = new Transaction();
				trans2.setTransAmount(balance);
				trans2.setTransFrom(sAccountNumber);
				trans2.setTransTo("-");
				trans2.setAccountNumber(rAccountNumber);
				trans2.setType("Received");
				tdao.save(trans2);
				return dao.findAll();
			} else {
				throw new AccountNotFoundException("Insufficient Balanace!!");
			}
		} else {
			throw new AccountNotFoundException("Account doesn't exists!!");
		}
	}

	@Override
	public List<Transaction> printTranscation(@Valid String accountNumber) throws AccountNotFoundException {

		if (dao.existsById(accountNumber)) {

			List<Transaction> transAll = tdao.findAll();
			List<Transaction> trans = new ArrayList<Transaction>();
			for (Transaction t : transAll) {
				if (t.getAccountNumber().equals(accountNumber))
					trans.add(t);
			}
			if (trans.isEmpty())
				throw new AccountNotFoundException("No transaction available");
			else
				return trans;
		} else
			throw new AccountNotFoundException("This Account Doesn't exists");
	}

}
